function classy = classifyimage(svm,DataCells,binConfig)
	svl=[]; 
	svd=[]; 
    classy=[];
	fflush(stdout); 
    radius=500;
	for i=(2*radius):(2*radius):(size(DataCells{1},1)-(2*radius)); 
		for j=(2*radius):(2*radius):(size(DataCells{1},2)-(2*radius)); 
            [~,sizes]=neighborhood(DataCells{1},[i,j],radius);
        	pile=svmRFDExtract(
                DataCells,
                'rbins',binConfig.rbins,
                'sines',binConfig.sines,
                'radius',radius,
                'point',[i,j],
                'array'); 
            classymini=[];
            dat=[];
            fakel=[];
            for y=1:size(pile,2)
                datt=pile(:,y,:);
                datt=permute(datt,[1,3,2]);
                fakelt=zeros(size(dat,1),1);
                dat=[dat;datt'];
                fakel=[fakel;fakelt];
                printf('.'); fflush(stdout);
            endfor
            printf(' * ');
            size(dat)
            predline=svmpredict( double(fakel), double(dat), svm);
            classymini=reshape(predline,size(pile,1),size(pile,2));
            classy(sizes{1},sizes{2})=classymini ;
            printf(':');
        endfor
    endfor
endfunction
