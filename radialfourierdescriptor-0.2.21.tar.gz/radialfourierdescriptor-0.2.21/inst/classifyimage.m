function classy = classifyimage(svm,DataCells,binConfig)
	svl=[]; 
	svd=[]; 
    classy=[];
	fflush(stdout); 
    radius=500;
	for i=(radius+10):(2*radius):(size(DataCells{1},1)-(radius+10)); 
		for j=(radius+10):(2*radius):(size(DataCells{1},2)-(radius+10)); 
            [~,sizes]=neighborhood(DataCells{1},[i,j],radius);
        	pile=svmRFDExtract(
                DataCells,
                'rbins',binConfig.rbins,
                'sines',binConfig.sines,
                'radius',radius,
                'point',[i,j],
                'array'); 
            classymini=[];
            dat=[];
            fakel=[];
            for y=1:size(pile,2)
                datt=pile(:,y,:);
                datt=permute(datt,[1,3,2]);
                fakelt=zeros(size(datt,1),1);
                dat=[dat;datt];
                fakel=[fakel;fakelt];
                printf('.'); fflush(stdout);
            endfor
            printf(' * ');
            predline=svmpredict( double(fakel), double(dat), svm);
            classymini=reshape(predline,size(pile,1),size(pile,2));
            classy(sizes{1},sizes{2})=classymini ;
            printf(':');
        endfor
    endfor
endfunction
