#!/bin/bash
wget 'http://storage.googleapis.com/earthengine-public/landsat/L8/045/028/LC80450282015055LGN00.tar.bz' -O L8data.tar.bz
tar xjvf L8data.tar.bz
