#!/bin/bash
wget 'http://storage.googleapis.com/earthengine-public/landsat/L8/027/040/LC80270402015265LGN00.tar.bz' -O L8data.tar.bz
tar xjvf L8data.tar.bz
