#!/bin/bash
wget 'http://storage.googleapis.com/earthengine-public/landsat/L8/016/037/LC80160372015028LGN00.tar.bz' -O L8data.tar.bz
tar xjvf L8data.tar.bz
