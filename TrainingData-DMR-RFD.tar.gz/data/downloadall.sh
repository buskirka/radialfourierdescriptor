#!/bin/bash
for i in $(ls)
do
    if [ -d $i ]
    then
    echo $i ;
        if [ -e $i/download.sh ]
        then
            cd $i ;
            bash download.sh ;
            cd .. ;
        fi
    fi
done
