function classy = classifyimage(svm,DataCells,binConfig)
	svl=[]; 
	svd=[]; 
    classy=[];
	fflush(stdout); 
    radius=500;
	for i=(2*radius):(2*radius):(size(DataCells{1},1)-(2*radius)); 
		for j=(2*radius):(2*radius):(size(DataCells{1},2)-(2*radius)); 
            [~,sizes]=neighborhood(DataCells{1},[i,j],radius);
        	pile=svmRFDExtract(
                DataCells,
                'rbins',binConfig.rbins,
                'sines',binConfig.sines,
                'radius',radius,
                'point',[i,j],
                'array'); 
            classymini=[];
            for y=1:size(pile,2)
                dat=pile(:,y,:);
                dat=permute(dat,[1,3,2]);
                fakel=zeros(size(dat,1),1);
                predline=svmpredict( double(fakel), double(dat), svm, '-q');
                classymini=[classymini;predline'];
                printf('.'); fflush(stdout);
            endfor
            classy(sizes{1},sizes{2})=classymini ;
            printf(':');
        endfor
    endfor
endfunction
